Quick Functions Lite v1.8
by @justarry for Minecraft Bedrock v1.18+

Functions:
/function qfinfo - About Quick Functions.
/function gmc - Creative Mode.
/function gms - Survival Mode.
/function gma - Adventure Mode.
/function cmdblock - Gives Command Block.
/function endlag - Removes [type=item] and [type=tnt] to try to reduce lag.
/function tree - Creates an Oak Tree where your standing.
/function givesword - Gives a Netherite Sword.
/function hell - Sends you to Nether.
/function heaven - Sends you to The End.
/function gapples - Gives 3 Golden Apples.
/function top - Teleports you 100 blocks into the air.
/function doublehealth - Doubles Healthbar for 2 minutes.
/function day - Sets time to Day.
/function night - Sets time to Night.
/function midnight - Sets time to Midnight.
/function hard - Sets Difficulty to Hard.
/function peaceful - Sets Difficulty to Peaceful (coward.)
/function respawn - Sets Respawn Point to Position.
/function sunlight - Sets weather to clear.
/function rain - Sets weather to raining.
/function thunder - Sets weather to thundering.
/function flatplane - Flattens the area around you.
/function extinguish - Extinguishs fire around you.
/function cube - Creates a 10x10x10 cube around you.