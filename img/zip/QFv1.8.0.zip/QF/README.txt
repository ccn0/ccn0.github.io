Quick Functions v1.8
by @justarry for Minecraft Bedrock v1.18+

Functions:
/function qfinfo - About Quick Functions.
/function gmc - Creative Mode.
/function gms - Survival Mode.
/function gma - Adventure Mode.
/function pyrokinesis - Set everything on fire around you in a 5 block radius.
/function cmdblock - Gives Command Block.
/function endlag - Removes [type=item] and [type=tnt] to try to reduce lag.
/function killplayers - Kills all players.
/function tree - Creates an Oak Tree where your standing.
/function tpall - Teleports all players online to YOU.
/function whine - Asks all players online for help.
/function bow - Gives a Bow and 3 Arrows.
/function givesword - Gives a Netherite Sword.
/function blind - Gives all players Blindness and Darkness effect for 10 seconds.
/function hell - Sends you to Nether.
/function heaven - Sends you to The End.
/function gapples - Gives 3 Golden Apples.
/function top - Teleports you 100 blocks into the air.
/function doublehealth - Doubles Healthbar for 2 minutes.
/function nuke - Spawns TNT from above you.
/function sponge - Makes a cube of water and give you a sponge.
/function lagall - Teleports all entities to you and creates an azalea plant cube.
/function day - Sets time to Day.
/function night - Sets time to Night.
/function midnight - Sets time to Midnight.
/function hard - Sets Difficulty to Hard.
/function peaceful - Sets Difficulty to Peaceful (coward.)
/function rich - Replaces nearby grass blocks with gold blocks.
/function supernuke - Same as nuke, but TWICE THE POWER AND RANGE.
/function respawn - Sets Respawn Point to Position.
/function sunlight - Sets weather to clear.
/function rain - Sets weather to raining.
/function thunder - Sets weather to thundering.
/function airstrike - Spawns TNT from Y-Level 100.
/function center - Teleports all players online to x0 z0.
/function mach10 - Gives Speed 10 for 30 seconds.
/function seizure - Shakes camera violently for 10 seconds.
/function reenforcements - Teleports all players to you and gives them armor.
/function flatplane - Flattens the area around you.
/function extinguish - Extinguishs fire around you.
/function cube - Creates a 10x10x10 cube around you.
/function armageddon - Creates a nuke, supernuke, airstrike, and fire cube in your location.

Kits:
/function stable - Gives 64 fences, 3 Leads, and spawns three Horses.
/function knight - Gives All Iron Armor and Sword.
/function nethergear - Gives All Netherite Armor and Sword.
/function farmer - Gives Iron Hoe and 64 Wheat Seeds.
/function village - Gives 4 Beds, 4 Villager Eggs, 64 Oak Logs, 32 Dirt, 2 Water Bucket, and a bell.
/function witch - Gives Strength 2 Potion and Leather Tunic.
/function archer - Gives Leather Tunic, Bow, and 64 Arrows.
/function pigman - Gives Golden Sword, Golden Helmet, and 10 Cooked Porkchops.